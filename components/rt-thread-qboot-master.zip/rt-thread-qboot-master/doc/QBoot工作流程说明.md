﻿## QBoot工作流程说明 ##

![QBoot流程图](figures/QBoot.jpg)