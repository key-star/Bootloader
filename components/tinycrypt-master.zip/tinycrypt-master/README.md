# tinycrypt

A simple and configurable crypt library
